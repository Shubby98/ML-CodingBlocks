# export PYTHONSTARTUP=/Users/panwu/Code/pylib/pylib/startup.py

import datetime, os, sys
print(" (imported datetime, os, sys) ")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

print(" (imported np, pd, plt) ")
#import datetime, os, pprint, re, sys, time
#print("(imported datetime, os, pprint, re, sys, time)")
